#include <iostream>
using namespace std;

int oddSum( int a, int b )
{

}

int main()
{

}