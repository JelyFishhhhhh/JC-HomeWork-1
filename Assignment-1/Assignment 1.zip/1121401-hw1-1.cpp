#include <iostream>
using namespace std;

int main()
{
   int number;

   cout << "Enter a positive integer: ";
   cin >> number;



}