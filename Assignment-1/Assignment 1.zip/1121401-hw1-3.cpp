#include <iostream>
using namespace std; 

int main()
{
   int number;

   cout << "Enter a 5-digit positive integer: ";
   cin >> number;



}