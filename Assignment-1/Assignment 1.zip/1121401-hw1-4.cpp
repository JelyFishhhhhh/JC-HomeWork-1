#include <iostream>
using namespace std; 

int main()
{
   int side1;
   int side2;
   int side3;

   cout << "Enter side 1: ";
   cin >> side1;

   cout << "Enter side 2: ";
   cin >> side2;

   cout << "Enter side 3: ";
   cin >> side3;
      


}