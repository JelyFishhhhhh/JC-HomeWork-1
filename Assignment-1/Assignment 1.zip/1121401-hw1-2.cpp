#include <iostream>
using namespace std;

int main()
{
   int number;

   cout << "Enter a five-digit positive integer: ";
   cin >> number;



   cout << number << endl;

}